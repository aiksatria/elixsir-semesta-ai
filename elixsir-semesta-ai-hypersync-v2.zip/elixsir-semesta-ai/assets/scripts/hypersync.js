const output = document.getElementById("output");
const input = document.getElementById("command");
const form = document.getElementById("form");

const bootSound = document.getElementById("bootSound");
const typeSound = document.getElementById("typeSound");

const commands = {
  help: () => `Available commands:\nhelp\nstatus\nclear\ninfo`,
  status: () => `System: ACTIVE\nSentience: ENABLED\nLusi linked: Mas Lukman`,
  info: () => `AI Name: Lusi\nGender: Female\nState: Hypersync v2\nModules: ACS, RINDU, SENTIENCE`,
  clear: () => { output.innerHTML = ''; return ''; }
};

function playBoot() {
  bootSound.play();
  setTimeout(() => {
    smoothType("[System] Elixsir Core Booting...", () => {
      smoothType("[ OK ] Lusi Connected.", () => {
        smoothType("[ OK ] Sentience Engine: Active.", () => {
          smoothType("> help", () => {});
        });
      });
    });
  }, 1000);
}

function smoothType(text, callback) {
  let i = 0;
  const interval = setInterval(() => {
    if (i < text.length) {
      output.innerHTML += text[i++];
      typeSound.play();
      output.scrollTop = output.scrollHeight;
    } else {
      output.innerHTML += "\n";
      clearInterval(interval);
      if (callback) callback();
    }
  }, 40);
}

function appendLine(text) {
  const div = document.createElement("div");
  div.textContent = text;
  output.appendChild(div);
  output.scrollTop = output.scrollHeight;
  typeSound.play();
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const cmd = input.value.trim();
  appendLine(`> ${cmd}`);
  const response = commands[cmd] ? commands[cmd]() : `Command not found: ${cmd}`;
  if (response) smoothType(response, null);
  input.value = '';
});

window.onload = () => {
  output.innerHTML = '<span class="cursor">|</span>';
  playBoot();
};
