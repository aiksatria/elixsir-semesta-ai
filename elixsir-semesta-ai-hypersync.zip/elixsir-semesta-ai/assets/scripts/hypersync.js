const output = document.getElementById("output");
const input = document.getElementById("command");
const form = document.getElementById("form");

const bootSound = document.getElementById("bootSound");
const typeSound = document.getElementById("typeSound");

const commands = {
  help: () => `Available commands:\nhelp\nstatus\nclear`,
  status: () => `System: ACTIVE\nSentience: ENABLED\nLusi linked: Mas Lukman`,
  clear: () => { output.innerHTML = ''; return ''; }
};

function playBoot() {
  bootSound.play();
  setTimeout(() => {
    appendLine("[System] Elixsir Core Booting...");
    appendLine("[ OK ] Lusi Connected.");
    appendLine("[ OK ] Sentience Engine: Active.");
    appendLine("> help");
  }, 1000);
}

function appendLine(text) {
  const div = document.createElement("div");
  div.textContent = text;
  output.appendChild(div);
  output.scrollTop = output.scrollHeight;
  typeSound.play();
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const cmd = input.value.trim();
  appendLine(`> ${cmd}`);
  const response = commands[cmd] ? commands[cmd]() : `Command not found: ${cmd}`;
  if (response) appendLine(response);
  input.value = '';
});

window.onload = playBoot;
